>**Note**: Please **fork** the current Udacity repository so that you will have a **remote** repository in **your** Github account. Clone the remote repository to your local machine. Later, as a part of the project "Post your Work on Github", you will push your proposed changes to the remote repository in your Github account.

### Date created
Wed 21 Dec
### Project Title
Project 3, Github Project

### Description
This project has 5 swctions:
1. Set Up Your Repository
2. Improve Documentation
3. Additional Changes to Documentation
4. Refactor Code
5. Merge Branches

### Files used
1- README file 
2- bikeshare.py
3- .gitignore

### Credits
It's important to give proper credit. Add links to any repo that inspired you or blogposts you consulted.

### About me:
I'm Shahad Almohaimeed
